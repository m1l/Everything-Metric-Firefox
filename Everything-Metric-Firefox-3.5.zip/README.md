# Everything Metric
 
Automatically translates all sites from American and Imperial units to International System of units (SI/Metric), adding converted unit in brackets behind USC/imperial units.

Example: 10 feet (3 m)˜

Extension published here
https://addons.mozilla.org/en-US/firefox/addon/everything-metric-converter/

Chrome version is available here https://github.com/m1l/Everything-Metric

Starting code based on https://github.com/esprimo/imperial-to-metric-chrome-extension

You can test conversion in action at
https://www.linkedin.com/pulse/everything-metric-chrome-firefox-milos-paripovic/
